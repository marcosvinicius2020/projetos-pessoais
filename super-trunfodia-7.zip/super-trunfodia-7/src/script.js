var cartapaulo = (
  nome: " seyia de pegaso "
  atributos:{
  ataque: 80,
  defesa: 60,
  magia: 90,
  }
)

var cartarafa = (
  nome: " bulbasauro "
  atributos:{
  ataque: 70,
  defesa: 65,
  magia: 85,
  }
)

var cartaguilherme = (
  nome: " lorde darth vader "
  atributos:{
  ataque: 88,
  defesa: 62,
  magia: 90,
  }
)

var cartas = [cartapaulo, cartarafa, cartaguilherme]

function sortearcarta(){
  var numerocartamaquina =  parseInt(Math.random() * 3)
  cartamaquina = cartas[numerocartamaquina]
  
   var numerocartajogador =  parseInt(Math.random() * 3)
   while (numerocartajogador == numerocartamaquina){
     numerocartajogador = parseInt(Math.random() * 3)
   }
  cartajogador = cartas[numerocartajogador]
  
  
  document.getElementById(btnSortear).disabled = true
   document.getElementById(btnJogar).disabled = false
}

function exibiropcoes(){
  var opcoes = document.getElementById("opcoes")
  var opcoestexto = ""
  for(var atributo in cartaJogador.atributos){'
    opcoestexto += "<input type='radio' name='atributo' value='' " + atributo + "'>" + atributo
  }
  opcoes.innerHTML = opcoestexto
}
function obtematributoselecionado(){
  var radioatributo = document.getElementsByName("atributo")
  for(var i = 0; i < radioatributo.length; i++){
    if(radioatributo[i].checked){
      return radioatributo[i].value
    }
  }
  function jogar(){
   var atributoselecionado = obtematributoselecionado()
   if(cartajogador.atributos[atributoselecionado] > cartamaquina.atributos[atributoselecionado])
     alert("venceu a maquina")
  }else if(cartajogador.atributos[atributoselecionado] < cartamaquina.atributos[atributoselecionado]){
    alert("perdeu a carta da maquina e maior")
  }else{
    alert("empatou")
  }
}