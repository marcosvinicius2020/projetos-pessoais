var numeroSecreto = parseInt(Math.random() * 10)
alert(numeroSecreto)
var tentativas = 3

while(tentativas > 0){
  
  var chute = parseInt(prompt("digite um numero de 0 a 10"))

  if(numeroSecreto == chute){
     alert("<input>acertou</input>")
      break
  }else if(chute > numeroSecreto){
     alert("<input>o número secreto é menor</input>")
     tentativas = tentativas - 1
  }else if(chute < numeroSecreto){
    alert("<input>o número secreto é maior</input>")
    tentativas = tentativas - 1
  }
}

if(chute != numeroSecreto){
  alert("<input>Suas tentaivas acabaram. O numero secreto era </input>" + numeroSecreto)
}