var paulo = (
  nome: "paulo"
  vitorias: 2 
  empates: 5
  derrotas: 1
  pontos: 0
)

var rafa = (
  nome: "rafa"
  vitorias: 3 
  empates: 5
  derrotas: 2
  pontos: 0
)

rafa.pontos = calculapontos(rafa)
paulo.pontos = calculapontos(paulo)

calculap-ontos(jogadores)

function calculapontos(jogador){
  var pontos = (jogador.vitorias * 3) + jogador.empates
  return pontos
}

var jogadores = [rafa, paulo]

exibirjogadoresnatela(jogadores)

function exibirjogadoresnatela(jogadores){
  var html  = ""
  for(var i = 0; i < jogadores.length; i++){
    html += "<tr><td>" + jogadores[i].nome + "</td>"
    html += "<td>" + jogadores[i].vitorias  + "</td>"
    html += "<td>" + jogadores[i].empates + "</td>"
    html += "<td>" + jogadores[i].derrotas + "</td>"
    html += "<td>" + jogadores[i].pontos + "</td>"
    html += "<td><buttom onclick='adicionarVitoria(" + i + " )'>vitoria</buttom></td>"
    html += "<td><buttom onclick='adicionarEmpate(" + i + " )'>empate</buttom></td>"
    html += "<td><buttom onclick='adicionarDerrota(" + i + ")'>derrota</buttom></tr></td>"
  }
  var tabelajogadores = document.getElementById("tabelajogadores")
  tabelajogadores.innerHTML = html
}

function adicionarVitoria(i){
  var jogador = jogadores[i]
  jogador.vitorias++
  jogador.pontos = calculapontos(jogador)
  exibirjogadoresnatela(jogadores)
}

function adicionarEmpate(i){
   var jogador = jogadores[i]
  jogador.empate++
  jogador.pontos = calculapontos(jogador)
  exibirjogadoresnatela(jogadores)
}

function adicionarDerrota(i){
   var jogador = jogadores[i]
   jogador.empate++
   exibirjogadoresnatela(jogadores)
}