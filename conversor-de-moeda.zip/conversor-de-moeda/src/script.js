var valorEmDolarTexto = prompt("qual o valor em dolar vocé quer converter?")

var valorEmDolarNumero = parseFloat(valorEmDolarTexto)

var valorEmreal = valorEmDolarNumero * 5.50

valorEmreal.toFixed(2)

alert(valorEmreal)