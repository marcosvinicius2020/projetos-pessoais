function adicionarFilme(){
  var campofilmefavorito = document.querySelector('#filme')
  var filmefavorito = campofilmefavorito.value
  if(filmefavorito.endsWith(".jpg")){
     listadefilmesnatela(filmefavorito) 
  }else {
    alert("imagem invalida")
  }
  campofilmefavorito.value = ""
}

function listadefilmesnatela(filme){
  var listafilmes = document.querySelector('#listafilmes')
  var elementofilme = "<img src=" + filme + ">"
  listafilmes.innerHTML = listafilmes.innerHTML + elementofilme
}