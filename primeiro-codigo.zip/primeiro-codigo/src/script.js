var nome = "rafaella"
var idade= 72

var idadeUsuario = prompt("quantos anos vocé tem?")
var idadeUsuarioComoNumero =  parseInt(idadeUsuario)
 idadeuarioComoNumero = idadeUsuarioComoNumero + 1
alert(idadeUsuarioComoNumero)